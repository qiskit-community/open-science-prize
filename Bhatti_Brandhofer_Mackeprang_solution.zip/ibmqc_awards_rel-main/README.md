The jupyter notebook should run out of the box. You may need to pip install z3-solver but this is included in the requirements.txt file. Changes were made to the original jupyter notebook in cell 20, 13, 12, 11, 6, 3, 2, model.py and requirements.txt.

Thank you for consideration!
