import copy
import pickle
import sys
import numpy as np

from qiskit import QuantumCircuit
from qiskit.providers.aer.noise.device import gate_length_values, thermal_relaxation_values
from z3 import BitVec, Optimize, Xor, Bool, Real, Implies, Not, Or, If, Sum, And, unsat, Int
import logging
#logging.basicConfig(level=logging.DEBUG)
logging.basicConfig(level=logging.WARNING)


def cnots_collide(param, param1):
    return param[0] == param1[0], param[0] == param1[1], param[1] == param1[0],  param[1] == param1[1]




class solve_graph_state():
    # DONE use times from casablanca backend: h, cx times, coherence times
    # DONE objective: longest coherence time
    # DONE objective: qubits idle as long as possible
    # DONE objective: qubits in target spectators idle during cnot
    # TODO generate circuit from results...
    #  with id gates
    def __init__(self, objectives=None, gl_in="casablance_gatelengths.p", t1t2_in="casablance_t1t2.p"):
        self.placed_cnots = None

        if objectives is None:
            self.objectives = ["h"]
            self.objectives = ["coherence_time"]
            self.objectives = ["coherence_time", 'runtime', 'h']
            self.objectives = ["runtime"]
            self.objectives = ["h"]
            self.objectives = ["least_cnot_target_with_h_infront"]
            self.objectives = ['h', "min_target_spectator", 'least_cnot_target_with_h_infront', 'coherence_time']
            self.objectives = ["min_target_spectator", "runtime"]
            #self.objectives = ["runtime"]
            self.objectives = ["coherence_time"]
        else:
            self.objectives = objectives

        self.solver = Optimize()
        self.is_model_build = False
        self.P = 7
        self.runtime = None
        self.min_coherence_time = None
        self.target_viol = None
        self.HALAP = None
        self.HALAP_cnot = None
        self.CNOTS_c = [(0, 1), (1, 2), (1, 3), (3, 5), (5, 4), (5, 6)]
        self.CNOTS_t = [tuple(list(reversed(t))) for t in self.CNOTS_c]
        self.allCNOTS = self.CNOTS_c + self.CNOTS_t
        self.allCX_TargetSpectators = [[2, 3], [], [5], [4, 6], [], [], [], [0, 3], [0, 2], [1], [3, 6], [4,3]]
        self.singleHadamardLocations = list(range(self.P))
        self.CNOTS_num = len(self.CNOTS_c + self.CNOTS_t)
        twhs = [t[1] for t in self.CNOTS_c + self.CNOTS_t]
        self.two_qubit_hadamards = []
        for twh in twhs:
            self.two_qubit_hadamards.append(twh)
            self.two_qubit_hadamards.append(twh)

        self.qubit_to_hadamard = {k : [k] for k in self.singleHadamardLocations}
        for i, cx in enumerate(self.CNOTS_c + self.CNOTS_t):
            t = cx[1]
            h0 = i*2 + len(self.singleHadamardLocations)
            h1 = h0+1
            self.qubit_to_hadamard[t].append(h0)
            self.qubit_to_hadamard[t].append(h1)

        for i in range(len(self.CNOTS_c)):
            assert self.CNOTS_c[i][0] == self.CNOTS_t[i][1] and self.CNOTS_c[i][1] == self.CNOTS_t[i][0]

        self.Hadamards_num = len(self.singleHadamardLocations + self.two_qubit_hadamards)

        self.considered_precision = 3
        if gl_in is not None and isinstance(gl_in, str):
            gl = pickle.load(open(gl_in, 'rb'))
            logging.debug(gl)
            self.gl = {}
            for name, qubits, value in gl:
                # TODO !!!Convert all gate lengths to nanosecond units
                # time = value# * _NANOSECOND_UNITS[gate_length_units]
                self.gl[name, "_".join(map(str, qubits))] = round(value, self.considered_precision)
        elif gl_in is not None:
            #self.gl[name, "_".join(map(str, qubits))] = round(value, self.considered_precision)
            self.gl = {}
            for name, qubits, value in gate_length_values(gl_in):
                self.gl[name, "_".join(map(str, qubits))] = round(value, self.considered_precision)

        #print(self.gl)
        for q in map(str, self.singleHadamardLocations):
            self.gl['h', q] = self.gl.get(('rz', q), 0.0)*2 + self.gl.get(('sx', q), 35.556)

        self.h_gate_time = self.gl['h', '0']
        self.min_time = -self.h_gate_time
        """
        self.t1t2freq = [(111137.90017558918, 62673.53951251921, 4.822059895392855),
                         (113436.42442657483, 76250.19631601262, 4.7599162649103555),
                         (114736.41337545004, 142660.6907358595, 4.907318399560602),
                         (110643.6421037132, 167864.1035461584, 4.878962629738054),
                         (75000.35661302856, 39937.807860261906, 4.870899140850027),
                         (82599.3523294855, 155552.46652353203, 4.96396742497092),
                         (80474.13495942688, 160948.26991885377, 5.177099260848073)]
        """
        if t1t2_in is not None and isinstance(t1t2_in, str):
            self.t1t2freq = pickle.load(open(t1t2_in, 'rb'))
        elif t1t2_in is not None:
            self.t1t2freq = thermal_relaxation_values(t1t2_in)

        logging.debug(self.t1t2freq)

        self.t1t2freq = [round(min(t1t2[:2]), self.considered_precision) for t1t2 in self.t1t2freq]
        logging.info(self.gl)
        logging.debug(self.t1t2freq)


    def create_vars(self):
        self.two_qubit_gates_vec = [Bool('one_CNOT_chosen_{}'.format(i)) for i in range(self.CNOTS_num)]
        self.two_qubit_start_time = [Real("CNOT_start_{}".format(i)) for i in range(self.CNOTS_num)]
        self.two_qubit_end_time = [Real("CNOT_end_{}".format(i)) for i in range(self.CNOTS_num)]

        self.hadamards_start_time = [Real("H_start_{}".format(i)) for i in range(self.Hadamards_num)]
        self.hadamards_end_time = [Real("H_end_{}".format(i)) for i in range(self.Hadamards_num)]
        self.hadamard_cancelled = [Bool("H_cancel_{}".format(i)) for i in range(self.Hadamards_num)]

        self.cnot_is_first_on_q = [[Bool("CNOT_{}_FIRST_ON_{}".format(i, q)) for i in range(self.CNOTS_num)] for q in self.singleHadamardLocations]

        for i in range(self.CNOTS_num):
            for q in self.singleHadamardLocations:
                if q in self.allCNOTS[i]:
                    self.solver.add(self.cnot_is_first_on_q[q][i] == And(self.two_qubit_gates_vec[i], *self.is_first_on_qubit(i, q)))
                else:
                    self.solver.add(Not(self.cnot_is_first_on_q[q][i]))


    def build_model(self):
        self.is_model_build = True
        self.create_vars()

        # choose only one cnot
        for i in range(len(self.CNOTS_c)):
            self.solver.add(Xor(self.two_qubit_gates_vec[i], self.two_qubit_gates_vec[i + 6]))

        # time domain
        for start in self.two_qubit_start_time+self.hadamards_start_time:
            #self.solver.add(Or(start >= 0.0, start == self.min_time))
            self.solver.add(start >= self.min_time)

        shl = len(self.singleHadamardLocations)

        # unused CNOTS
        for i in range(self.CNOTS_num):
            self.solver.add(Implies(Not(self.two_qubit_gates_vec[i]), self.two_qubit_start_time[i] == self.min_time))
            self.solver.add(Implies(Not(self.two_qubit_gates_vec[i]), self.two_qubit_end_time[i] == self.min_time))
            self.solver.add(Implies(Not(self.two_qubit_gates_vec[i]), self.hadamards_start_time[i*2 + shl] == self.min_time))
            self.solver.add(Implies(Not(self.two_qubit_gates_vec[i]), self.hadamards_start_time[i*2 + shl + 1] == self.min_time))
            self.solver.add(Implies(Not(self.two_qubit_gates_vec[i]), self.hadamards_end_time[i*2 + shl] == self.min_time))
            self.solver.add(Implies(Not(self.two_qubit_gates_vec[i]), self.hadamards_end_time[i*2 + shl + 1] == self.min_time))

        # fix timing used CNOTS
        for i in range(self.CNOTS_num):
            #self.solver.add(Implies(self.two_qubit_gates_vec[i], self.two_qubit_end_time[i] == self.two_qubit_start_time[i] + self.cnot_gate))
            self.solver.add(Implies(self.two_qubit_gates_vec[i], self.two_qubit_end_time[i] == self.two_qubit_start_time[i] + self.gl['cx',"_".join(map(str, self.allCNOTS[i]))]))

            self.solver.add(Implies(self.two_qubit_gates_vec[i], self.hadamards_start_time[i*2 + shl] == self.two_qubit_start_time[i] - self.h_gate_time))
            self.solver.add(Implies(self.two_qubit_gates_vec[i], self.hadamards_end_time[i*2 + shl] == self.two_qubit_start_time[i]))

            self.solver.add(Implies(self.two_qubit_gates_vec[i], self.hadamards_start_time[i*2 + shl + 1] == self.two_qubit_end_time[i]))
            self.solver.add(Implies(self.two_qubit_gates_vec[i], self.hadamards_end_time[i*2 + shl + 1] == self.two_qubit_end_time[i] + self.h_gate_time))



        for q in range(len(self.singleHadamardLocations)):
            for i in range(self.CNOTS_num):
                # and first cnot on qubit
                if self.allCNOTS[i][1] == q:
                    self.solver.add(Implies(And(self.two_qubit_gates_vec[i], *self.is_first_on_qubit(i, q)), self.two_qubit_start_time[i] >= 0.0))
                    #self.solver.add(Implies(And(self.two_qubit_gates_vec[i], *self.is_first_on_qubit(i, q)), self.hadamards_start_time[i*2+shl] == self.min_time))
                    #self.solver.assert_and_track(Implies(And(self.two_qubit_gates_vec[i], *self.is_first_on_qubit(i, q)), self.hadamards_start_time[i*2+shl] == self.min_time),"blaa")
                    self.solver.add(Implies(And(self.two_qubit_gates_vec[i], *self.is_first_on_qubit(i, q)), self.hadamards_start_time[q] == self.min_time))
                    self.solver.add(Implies(And(self.two_qubit_gates_vec[i], *self.is_first_on_qubit(i, q)), self.hadamards_end_time[q] == 0.0))
                elif self.allCNOTS[i][0] == q:
                    #self.solver.add(Implies(And(self.two_qubit_gates_vec[i], *self.is_first_on_qubit(i, q)), self.hadamards_start_time[i * 2 + shl] >= self.hadamards_end_time[q]))
                    self.solver.add(Implies(And(self.two_qubit_gates_vec[i], *self.is_first_on_qubit(i, q)), self.two_qubit_start_time[i] >= self.hadamards_end_time[q]))
                    self.solver.add(Implies(And(self.two_qubit_gates_vec[i], *self.is_first_on_qubit(i, q)), self.hadamards_start_time[q] >= 0.0))
                    self.solver.add(Implies(And(self.two_qubit_gates_vec[i], *self.is_first_on_qubit(i, q)), self.hadamards_end_time[q] == self.hadamards_start_time[q] + self.h_gate_time))

        """
        for i in range(self.CNOTS_num):
            self.solver.add(Implies(self.two_qubit_gates_vec[i], self.hadamards_start_time[i*2+shl] >= self.h_gate))
        """

        # a cnot ends before or starts after another cnot
        cnts = self.CNOTS_c + self.CNOTS_t
        for i in range(self.CNOTS_num):
            for j in range(self.CNOTS_num):
                if j == i or (i == j + 6) or (j == i + 6):
                    continue
                src_src, src_tar, tar_src, tar_tar = cnots_collide(cnts[i], cnts[j])

                if src_src:
                    # cnot ends before or starts after cnot
                    self.solver.add(Implies(self.two_qubit_gates_vec[i], Or(self.two_qubit_end_time[i] <= self.two_qubit_start_time[j], self.two_qubit_start_time[i] >= self.two_qubit_end_time[j])))
                if src_tar:
                    # ends before or starts after cnot-+H_gate
                    self.solver.add(Implies(self.two_qubit_gates_vec[i], Or(
                        self.two_qubit_end_time[i] <= self.hadamards_start_time[j*2 + len(self.singleHadamardLocations)],
                        self.two_qubit_start_time[i] >= self.hadamards_end_time[
                            j*2 + len(self.singleHadamardLocations) + 1])))
                if tar_src:
                    # cnot+-H_gate ends before or starts after cnot
                    self.solver.add(Implies(self.two_qubit_gates_vec[i], Or(
                        self.hadamards_end_time[i*2 + shl+1] <= self.two_qubit_start_time[j],
                        self.hadamards_start_time[i*2 + shl] >= self.two_qubit_end_time[j])))
                if tar_tar:
                    # without cancellation: cnot+-H_gate ends before or starts after cnot-+H_gate
                    # with cancellation: cnot gate ends before or starts after cnot gate

                    self.solver.add(Implies(self.two_qubit_gates_vec[i], Or(
                        self.two_qubit_end_time[i] <= self.two_qubit_start_time[j],
                        self.two_qubit_start_time[i] >= self.two_qubit_end_time[j])))

                    """
                    self.solver.add(Implies(self.two_qubit_gates_vec[i], Or(
                        self.hadamards_end_time[i*2 + shl + 1] <= self.hadamards_start_time[j*2 + shl],
                        self.hadamards_start_time[i*2 + shl] >= self.hadamards_end_time[j*2 + shl + 1])))
                    """


        # hadamard cancellation
        # TODO cancel hadamard if is first on qubit,
        #  self.solver.add(Implies(And(self.two_qubit_gates_vec[i], *self.is_first_on_qubit(i, q)), self.hadamards_start_time[q] == self.min_time))
        for i in range(self.Hadamards_num):
            if i < self.P:
                self.solver.add(self.hadamard_cancelled[i] == Or(self.hadamards_start_time[i] < 0.0, *[
                    And(self.two_qubit_start_time[cnot] <= self.hadamards_start_time[i],
                        self.hadamards_end_time[i] <= self.two_qubit_end_time[cnot]) for cnot in range(self.CNOTS_num) if self.cnot_is_on_same_qubit_as_hadamard(i, cnot)]))
            else:
                cnot_i = (i - len(self.singleHadamardLocations)) // 2
                self.solver.add(self.hadamard_cancelled[i] == Or(self.hadamards_start_time[i] < 0.0, And(self.two_qubit_gates_vec[cnot_i], *self.is_first_on_qubit(cnot_i, self.allCNOTS[cnot_i][1])) if i == (cnot_i*2 +len(self.singleHadamardLocations)) else False,
                                     *[And(self.two_qubit_start_time[cnot] <= self.hadamards_start_time[i], self.hadamards_end_time[i] <= self.two_qubit_end_time[cnot]) for cnot in range(self.CNOTS_num) if self.cnot_is_on_same_qubit_as_hadamard(i, cnot)]))

        for i in range(self.Hadamards_num):
            logging.debug("h:{} on same qubit [{}] as cnots {}".format(i, i if i < self.P else self.allCNOTS[(i-self.P)//2][1], [self.allCNOTS[cnot] for cnot in range(self.CNOTS_num) if self.cnot_is_on_same_qubit_as_hadamard(i, cnot)]))
        #print(self.allCNOTS)
        """
        for i in range(self.Hadamards_num):
            check_hlist = []
            q = self.h_pos(i)

            for j in range(self.Hadamards_num):
                if i==j:
                    continue
                p = self.h_pos(j)
                if q == p:
                    check_hlist.append(Or(self.hadamards_end_time[i] == self.hadamards_start_time[j], self.hadamards_end_time[j] == self.hadamards_start_time[i]))
            #alist = [Or(self.hadamards_end_time[i] == self.hadamards_start_time[j], self.hadamards_end_time[j] == self.hadamards_start_time[i]) for j in range(self.Hadamards_num) if j != i]
            #alist = [self.hadamards_end_time[i] == self.hadamards_start_time[j] for j in range(self.Hadamards_num) if j != i]
            #print(check_hlist)
            self.solver.add(self.hadamard_cancelled[i] == Or(check_hlist))
        """
        """
        for i in range(self.Hadamards_num):
            for j in range(self.Hadamards_num):
                if j == i:
                    continue
                self.solver.add(self.hadamard_cancelled[i] == Or(self.hadamards_end_time[i] == self.hadamards_start_time[j], self.hadamards_end_time[j] == self.hadamards_start_time[i]))
                #self.solver.add(self.hadamard_cancelled[i] == (self.hadamards_end_time[i] == self.hadamards_start_time[j]))
                print("{}: {}".format(i, j))
                self.solver.add(
                    If(self.hadamards_end_time[i] == self.hadamards_start_time[j], self.hadamard_cancelled[i], Not(self.hadamard_cancelled[i])))
                break
        """
        self.add_objectives()



    def solve(self):
        if not self.is_model_build:
            self.build_model()
        sat = self.solver.check()
        if sat == unsat:
            print(self.solver.unsat_core())
        logging.info("Solver: {}".format(sat))
        model = self.solver.model()
        for i in range(self.CNOTS_num):
            logging.debug("{} - {}".format(i, model[self.two_qubit_gates_vec[i]]))

        for i in range(self.Hadamards_num):
            logging.debug("H_{} cancel - {}".format(i, model[self.hadamard_cancelled[i]]))
        logging.info("Hadamards in circuit: {}".format(30-sum([model[self.hadamard_cancelled[i]].__bool__() for i in range(self.Hadamards_num)])))

        if self.runtime is not None:
            logging.info("runtime: {}".format(model[self.runtime].as_decimal(self.considered_precision)))

        if self.min_coherence_time is not None:
            logging.info("min coherence time: {}".format(model[self.min_coherence_time].as_decimal(self.considered_precision)))

        for i in range(self.CNOTS_num):
            for q in self.singleHadamardLocations:
                if model[self.cnot_is_first_on_q[q][i]]:
                    logging.debug("CNOT: {} first on {}".format(self.allCNOTS[i], q))

        shl = len(self.singleHadamardLocations)
        order = self.get_CNOT_order(model)
        self.cnot_times(model, order)
        #print(self.t1t2freq)
        for i in range(self.CNOTS_num):
                logging.info("{} - {}th CNOT [{}] h_prev [{}, {}] CX [{}, {}] h_next [{}, {}]".format(model[self.two_qubit_gates_vec[i]], i, self.allCNOTS[i], model[
                    self.hadamards_start_time[shl + i * 2]].as_decimal(self.considered_precision), model[
                                                                                           self.hadamards_end_time[
                                                                                               shl + i * 2]].as_decimal(
                    self.considered_precision), model[self.two_qubit_start_time[i]].as_decimal(
                    self.considered_precision), model[self.two_qubit_end_time[i]].as_decimal(self.considered_precision),
                                                                                       model[self.hadamards_start_time[
                                                                                           shl + i * 2 + 1]].as_decimal(
                                                                                           self.considered_precision),
                                                                                       model[self.hadamards_end_time[
                                                                                           shl + i * 2 + 1]].as_decimal(
                                                                                           self.considered_precision)))
        logging.debug(self.allCNOTS)
        if self.target_viol is not None:
            logging.info("viol: {}".format(model[self.target_viol]))
        self.qc = self.build_qc(model)
        #self.qc.measure_all()
        #print(self.qc)
        #print(self.qc.qasm())
        return self.qc

    def build_qc(self, model):
        qc_data = []

        #   "{} - {}th CNOT [{}] h_prev [{}, {}] CX [{}, {}] h_next [{}, {}]".format(model[self.two_qubit_gates_vec[i]],
        #                                                                             i, self.allCNOTS[i], model[
        for q in range(self.P):
            hs = [('h', h) for h in self.qubit_to_hadamard[q] if not model[self.hadamard_cancelled[h]]]
            cnots = [('cx', i) for i, cn in enumerate(self.allCNOTS) if q == cn[1] and model[self.two_qubit_gates_vec[i]]]
            gates = sorted(hs+cnots, key=lambda x: float(model[self.hadamards_end_time[x[1]]].as_decimal(self.considered_precision)) if x[0]=='h' else float(model[self.two_qubit_end_time[x[1]]].as_decimal(self.considered_precision)))
            #gates = sorted(hs+cnots, key=lambda x: print(x))
            logging.debug(gates)
            qc_data.append(gates)

        logging.debug(qc_data)
        def get_start_time(g):
            t = model[self.hadamards_start_time[g[1]]].as_decimal(self.considered_precision) if g[0] == 'h' else model[self.two_qubit_start_time[g[1]]].as_decimal(self.considered_precision)
            return float(t)

        def get_end_time(g):
            t = model[self.hadamards_end_time[g[1]]].as_decimal(self.considered_precision) if g[0] == 'h' else model[self.two_qubit_end_time[g[1]]].as_decimal(self.considered_precision)
            return float(t)

        def is_gate_in_qc_data(qc_data):
            return any([len(q)>0 for q in qc_data])

        def get_next_gate(qc_data, qc_data_idx):
            next_qubit = sorted(range(len(qc_data)), key=lambda k: get_start_time(qc_data[k][0]) if len(qc_data[k]) > 0 else np.inf)[0]
            next_gate = qc_data[next_qubit][0]
            qc_data_idx[next_qubit] += 1
            qc_data[next_qubit].pop(0)
            return next_gate, qc_data_idx[next_qubit], next_qubit


        qc = QuantumCircuit(self.P)
        qc_data_idx = [-1]*self.P
        qc_data_backup = copy.deepcopy(qc_data)
        while(is_gate_in_qc_data(qc_data)):
            gate, i, q = get_next_gate(qc_data, qc_data_idx)
            if i == 0:
                padding = round(float(get_start_time(gate))/self.h_gate_time)
                for t in range(padding):
                    qc.id(q)
                if gate[0] == 'h':
                    qc.h(q)
                elif gate[0] == 'cx':
                    qc.cx(*self.allCNOTS[gate[1]])
                else:
                    print("Unknown gate")
                    sys.exit()
            else:
                padding = round(float(get_start_time(gate)-float(get_end_time(qc_data_backup[q][i-1])))/self.h_gate_time)
                for t in range(padding):
                    qc.id(q)
                if gate[0] == 'h':
                    qc.h(q)
                elif gate[0] == 'cx':
                    qc.cx(*self.allCNOTS[gate[1]])
                else:
                    print("Unknown gate")
                    sys.exit()
        logging.debug(qc)
        logging.debug(qc_data_backup)
        return qc



    def add_objectives(self):
        #TODO incorperate cancellation in runtime computations...
        #TODO incorperate no (single) qubit computations on target-neighbor or control-neighbor qubits
        #self.solver.maximize(Sum([If(self.hadamard_cancelled[i], 1, 0) for i in range(len(self.hadamard_cancelled))]))
        for objective in self.objectives:
            if objective == 'h':
                self.solver.maximize(Sum([If(self.hadamard_cancelled[i], 1, 0) for i in range(len(self.hadamard_cancelled))]))
            if objective == 'runtime':
                self.runtime = Real("min_runtime")
                for t in self.hadamards_end_time+self.two_qubit_end_time:
                    self.solver.add(self.runtime >= t)
                self.solver.minimize(self.runtime)
            if objective == 'coherence_time':
                self.min_coherence_time = Real("coherence_time")
                for i, t in enumerate(self.hadamards_end_time+self.two_qubit_end_time):
                    q = self.from_i_time(i)
                    self.solver.add(self.min_coherence_time <= (self.t1t2freq[q] - t))
                self.solver.maximize(self.min_coherence_time)
            if objective == 'H_ALAP':
                self.HALAP = Real("H_as_late_as_possible")
                for i in range(self.Hadamards_num):
                    self.solver.add(Implies(Not(self.hadamard_cancelled[i]), self.HALAP <= self.hadamards_start_time[i]))
                self.solver.maximize(self.HALAP)
                print("Do not use this objective without any constraint on runtime, otherwise answer will be infinity")
            if objective == 'min_target_spectator':
                constr = []
                for i, cnot in enumerate(self.allCNOTS):
                    specs = self.allCX_TargetSpectators[i]
                    for spec in specs:
                        for hadamard in self.qubit_to_hadamard[spec]:
                            #target_spectating = And(Not(self.hadamard_cancelled[hadamard]), Not(Or(self.hadamards_end_time[hadamard] <= self.two_qubit_start_time[i], self.two_qubit_end_time[i] <= self.hadamards_start_time[i])))
                            #self.two_qubit_start_time[i] <= self.hadamards_end_time[hadamard] <= self.two_qubit_end_time[i], self.two_qubit_start_time[i] <= self.hadamards_start_time[hadamard] <= self.two_qubit_end_time[i]
                            target_spectating = And(Not(self.hadamard_cancelled[hadamard]), Or(
                                And(self.two_qubit_start_time[i] <= self.hadamards_end_time[hadamard],
                                    self.hadamards_end_time[hadamard] <= self.two_qubit_end_time[i]),
                                And(self.two_qubit_start_time[i] <= self.hadamards_start_time[hadamard],
                                    self.hadamards_start_time[hadamard] <= self.two_qubit_end_time[i])))
                            constr.append(target_spectating)
                self.target_viol = Int("target_viol")
                self.solver.add(self.target_viol == Sum([If(viol, 1, 0) for viol in constr]))
                self.solver.minimize(self.target_viol)
            if objective == 'least_cnot_target_with_h_infront':
                self.HALAP_cnot = Real("least_cnot_with_h")
                self.solver.add(self.HALAP_cnot == Sum([
                    Sum(
                    [If(And(Not(self.hadamard_cancelled[h]), self.hadamards_end_time[h] <= self.two_qubit_start_time[
                        i]), 1, 0) for h in self.qubit_to_hadamard[cnot[1]]])
                    for i, cnot in enumerate(self.allCNOTS)]))
                self.solver.minimize(self.HALAP_cnot)


    def get_CNOT_order(self, model):
        cnot_dict = {i: float(model[self.two_qubit_end_time[i]].as_decimal(self.considered_precision)) for i in range(self.CNOTS_num)}
        cnot_dict2 = {i: cnot_dict[i] for i in range(self.CNOTS_num) if cnot_dict[i] >= 0}

        self.placed_cnots = {k: v for k, v in sorted(cnot_dict2.items(), key=lambda item: item[1])}
        logging.info({self.allCNOTS[k]: v for k, v in sorted(cnot_dict2.items(), key=lambda item: item[1])})

        return cnot_dict2

    def cnot_times(self, model, order):
        for cnot in order:
            logging.debug("{}: {}".format(cnot, model[self.two_qubit_end_time[cnot]].as_decimal(self.considered_precision)))

    def h_pos(self, i):
        if i < self.P:
            return i
        cnot = (i - self.P) // 2
        return self.allCNOTS[cnot][1]

    def is_first_on_qubit(self, i, q):
        return [Or(self.two_qubit_end_time[i] < self.two_qubit_end_time[j], Not(self.two_qubit_gates_vec[j])) for j in
                range(self.CNOTS_num) if i != j and q in self.allCNOTS[j]]

    def from_i_time(self, i):
        #            for i, t in enumerate(self.hadamards_end_time+self.two_qubit_end_time):
        if i in self.singleHadamardLocations:
            return i
        if len(self.singleHadamardLocations) <= i < len(self.hadamards_end_time):
            cnot = (i-len(self.singleHadamardLocations)) // 2
            return self.allCNOTS[cnot][1]
        elif i >= len(self.hadamards_end_time):
            j = i - len(self.hadamards_end_time)
            return self.allCNOTS[j][0]
        else:
            print("Noooo!")
            sys.exit()


    def cnot_is_on_same_qubit_as_hadamard(self, hadamard, cnot):
        if hadamard < self.P:
            return hadamard == self.allCNOTS[cnot][1]
        return self.allCNOTS[(hadamard-self.P) // 2][1] == self.allCNOTS[cnot][1]




if __name__ == '__main__':
    sgs = solve_graph_state()
    sgs.build_model()
    sgs.solve()
    print("Done")