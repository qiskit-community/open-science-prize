# ======================================================================================
#
# Copyright: CERFACS, LIRMM, Total S.A. - the quantum computing team (/January/2021)
# Contributor: Adrien Suau (adrien.suau@cerfacs.fr)
#
# This program is free software: you can redistribute it and/or modify it under the
# terms of the GNU Lesser General Public License as published by the Free Software
# Foundation, either version 3 of the License, or (at your discretion) any later
# version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
# PARTICULAR PURPOSE.
#
# See the GNU Lesser General Public License for more details. You should have received
# a copy of the GNU Lesser General Public License along with this program. If not, see
# https://www.gnu.org/licenses/lgpl-3.0.txt
#
# ======================================================================================

from setuptools import setup, find_packages

setup(
    name="open-science-prize",
    version="0.0.1a",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    install_requires=[
        "qiskit[visualization]>=0.23.1",
        "networkx",
        "jupyter",
        "jupyterlab",
        "z3-solver",
    ],
    url="https://github.com/nelimee/open-science-prize",
    license="LGPL-v3",
    author="Adrien Suau <adrien.suau@lirmm.fr>, Siyuan Niu <siyuan.niu@lirmm.fr>",
    description="Open Science Prize participation from Adrien Suau and Siyuan Niu",
)
