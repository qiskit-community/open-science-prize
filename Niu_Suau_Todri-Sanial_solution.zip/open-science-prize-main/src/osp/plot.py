# ======================================================================================
#
# Copyright: CERFACS, LIRMM, Total S.A. - the quantum computing team (25/01/2021)
# Contributor: Adrien Suau (adrien.suau@cerfacs.fr)
#
# This program is free software: you can redistribute it and/or modify it under the
# terms of the GNU Lesser General Public License as published by the Free Software
# Foundation, either version 3 of the License, or (at your discretion) any later
# version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
# PARTICULAR PURPOSE.
#
# See the GNU Lesser General Public License for more details. You should have received
# a copy of the GNU Lesser General Public License along with this program. If not, see
# https://www.gnu.org/licenses/lgpl-3.0.txt
#
# ======================================================================================

from typing import Optional, List, Dict, Tuple

import networkx as nx
from matplotlib.axes import Axes
from matplotlib import cm
import matplotlib.colors
from matplotlib.colors import LogNorm
import matplotlib.pyplot as plt

import numpy

from osp.partition import edge_coloring


def plot_coloring(
    graph: nx.Graph, colors: Optional[List] = None, ax: Optional[Axes] = None
) -> None:
    """Plot the edge coloring of the given graph

    :param graph: graph to color.
    :param colors: colors used to plot the colored edges.
    :param ax: matplotlib axe on which to draw the graph.
    """
    coloring = edge_coloring(graph)
    if colors is None:
        colors = cm.get_cmap("Paired").colors
    edge_colors = [
        colors[coloring[edge]] if edge in coloring else colors[coloring[edge[::-1]]]
        for edge in graph.edges
    ]
    nx.draw(graph, edge_color=edge_colors, width=5)


def plot_cross_talk_impact(
    cross_talk_impacts: Dict[Tuple[int, int], Dict[Tuple[int, int], float]]
) -> None:
    link_num: int = len(cross_talk_impacts)
    indices: Dict[Tuple[int, int], int] = {
        u: i for i, u in enumerate(cross_talk_impacts)
    }
    impacts = numpy.zeros((link_num, link_num), dtype=float)

    for u, cross_talk_data in cross_talk_impacts.items():
        for v, cross_talk_impact in cross_talk_data.items():
            impacts[indices[u]][indices[v]] = cross_talk_impact

    # Construct the normaliser
    normaliser = LogNorm()
    normaliser.autoscale(impacts)
    # We want values below one to have a different color. We do this by creating a
    # new colormap that has the desired colors.
    greencm = plt.get_cmap("Greens")
    redcm = plt.get_cmap("Reds")
    one_value = normaliser(1)
    values_before_one = int(one_value * 256)
    colors = numpy.vstack(
        (
            greencm(numpy.linspace(0.2, 1, values_before_one))[::-1],
            redcm(numpy.linspace(0.2, 1, 258 - values_before_one)),
        )
    )
    cmap = matplotlib.colors.LinearSegmentedColormap.from_list("custom_cmap", colors)

    # Plot the colormap and the colorbar
    plt.matshow(impacts, norm=LogNorm(), cmap=cmap)
    plt.xticks(range(len(indices)), map(str, indices))
    plt.yticks(range(len(indices)), map(str, indices))
    colorbar = plt.colorbar()

    # Add text annotations
    for i, j in zip(*numpy.where(numpy.abs(impacts) > 1e-10)):
        text = plt.text(
            j, i, f"{impacts[i, j]:.2f}", ha="center", va="center", color="w"
        )
    return colorbar
