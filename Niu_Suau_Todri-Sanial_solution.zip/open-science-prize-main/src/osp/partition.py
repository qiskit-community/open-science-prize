# ======================================================================================
#
# Copyright: CERFACS, LIRMM, Total S.A. - the quantum computing team (25/01/2021)
# Contributor: Adrien Suau (adrien.suau@cerfacs.fr)
#
# This program is free software: you can redistribute it and/or modify it under the
# terms of the GNU Lesser General Public License as published by the Free Software
# Foundation, either version 3 of the License, or (at your discretion) any later
# version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
# PARTICULAR PURPOSE.
#
# See the GNU Lesser General Public License for more details. You should have received
# a copy of the GNU Lesser General Public License along with this program. If not, see
# https://www.gnu.org/licenses/lgpl-3.0.txt
#
# ======================================================================================

from typing import Union, List, Tuple, Dict
from itertools import permutations
from copy import deepcopy
import sys
import networkx as nx
import numpy

from qiskit.providers.ibmq import IBMQBackend

from osp.hardware import get_adjacency_matrix, get_native_coupling_map, get_execution_time

# high_crosstalk_pair = [(1,3),(4,5)]

def edge_coloring(
    adjacency_matrix: Union[List, numpy.array],
    cross_talk_impacts: Dict[Tuple[int, int], Dict[Tuple[int, int], float]],
    cross_talk_impact_threshold: float,
    minimum_link_distance: int,
) -> Dict[Tuple[int, int], int]:
    """Color the edges of the given graph.

    :param adjacency_matrix: represents the graph to color.
    :param cross_talk_impacts: a dictionary that stores the impact of cross-talk
        on the CX gate error rates. The entry cross_talk_impact[u][v] stores the
        ratio between the CX error rate on link u when link v also executes a CX
        and the CX error rate on link u when executed alone. In other words,
        if there is cross-talk between links u and v, the entries [u][v] and [v][
        u] should be strictly larger than one. In practice it may happen that
        some entries are less than 1 because of benchmarking inaccuracies.
    :param cross_talk_impact_threshold: a threshold to determine whether a
        cross-talk error rate is significant or can be ignored.
    :param minimum_link_distance: the minimum distance (number of links) that
        should be ensured between two CX executed in parallel. This parameter can
        be used to avoid potential cross-talk when the real cross-talk
        information are not known.
    :return: the coloring.
    """
    # Create the graph represented by the adjacency matrix.
    rows, cols = numpy.where(numpy.asarray(adjacency_matrix) == 1)
    graph = nx.Graph(zip(rows.tolist(), cols.tolist()))
    # Create the dual graph, i.e. exchange nodes and edges.
    dual_graph: nx.Graph = nx.line_graph(graph)

    # Add links to obey to the given minimum_link_distance. If we only need a
    # distance of 1 (default), this is already encoded in the graph so we can safely
    # ignore and do nothing.
    if minimum_link_distance > 1:
        shortest_paths = nx.all_pairs_shortest_path_length(
            dual_graph, cutoff=minimum_link_distance
        )
        for edge1, dictionary in shortest_paths:
            for edge2, length in dictionary.items():
                if length > 1:
                    dual_graph.add_edge(edge1, edge2)

    # Extract the links that have a significant cross-talk and modify the dual graph
    # in such a way that links with significant cross-talk between each other will
    # not be colored with the same color.
    for u, cross_talk_data in cross_talk_impacts.items():
        for v, cross_talk_impact in cross_talk_data.items():
            if cross_talk_impact > cross_talk_impact_threshold:
                # add a link between u and v such as the u and v edges in the
                # original graph will never be of the same color.
                dual_graph.add_edge(u, v)

    # Color the nodes of the dual graph.
    best_coloring: Dict[Tuple[int, int], int] = None
    best_color_number: int = len(dual_graph.nodes) + 1
    for greedy_strategy in [
        nx.algorithms.coloring.strategy_largest_first,
        nx.algorithms.coloring.strategy_smallest_last,
        nx.algorithms.coloring.strategy_connected_sequential_bfs,
        nx.algorithms.coloring.strategy_connected_sequential_dfs,
        nx.algorithms.coloring.strategy_independent_set,
        nx.algorithms.coloring.strategy_connected_sequential,
        nx.algorithms.coloring.strategy_random_sequential,
        nx.algorithms.coloring.strategy_saturation_largest_first,
    ]:
        coloring: Dict[Tuple[int, int], int] = nx.algorithms.coloring.greedy_color(
            dual_graph, strategy=greedy_strategy
        )
        color_number = max(coloring.values()) + 1
        if color_number < best_color_number:
            best_color_number = color_number
            best_coloring = deepcopy(coloring)
    return best_coloring


def edge_coloring_candidates(
    adjacency_matrix: Union[List, numpy.array],
    minimum_link_distance: int,
) -> List[Dict[Tuple[int, int], int]]:
    """Color the edges of the given graph.

    :param adjacency_matrix: represents the graph to color.
    :param minimum_link_distance: the minimum distance (number of links) that
        should be ensured between two CX executed in parallel. This parameter can
        be used to avoid potential cross-talk when the real cross-talk
        information are not known.
    :return: A list of coloring candidates that have best color number 3.
    """
    # Create the graph represented by the adjacency matrix.
    rows, cols = numpy.where(numpy.asarray(adjacency_matrix) == 1)
    graph = nx.Graph(zip(rows.tolist(), cols.tolist()))
    # Create the dual graph, i.e. exchange nodes and edges.
    dual_graph: nx.Graph = nx.line_graph(graph)

    # Add links to obey to the given minimum_link_distance. If we only need a
    # distance of 1 (default), this is already encoded in the graph so we can safely
    # ignore and do nothing.
    if minimum_link_distance > 1:
        shortest_paths = nx.all_pairs_shortest_path_length(
            dual_graph, cutoff=minimum_link_distance
        )
        for edge1, dictionary in shortest_paths:
            for edge2, length in dictionary.items():
                if length > 1:
                    dual_graph.add_edge(edge1, edge2)

    # Color the nodes of the dual graph.
    coloring_candidates = []
    best_coloring: Dict[Tuple[int, int], int] = None
    best_color_number: int = 3
    for greedy_strategy in [
        nx.algorithms.coloring.strategy_largest_first,
        nx.algorithms.coloring.strategy_smallest_last,
        nx.algorithms.coloring.strategy_connected_sequential_bfs,
        nx.algorithms.coloring.strategy_connected_sequential_dfs,
        nx.algorithms.coloring.strategy_independent_set,
        nx.algorithms.coloring.strategy_connected_sequential,
        nx.algorithms.coloring.strategy_random_sequential,
        nx.algorithms.coloring.strategy_saturation_largest_first,
    ]:
        coloring: Dict[Tuple[int, int], int] = nx.algorithms.coloring.greedy_color(
            dual_graph, strategy=greedy_strategy
        )
        color_number = max(coloring.values()) + 1
        if color_number <= best_color_number:
            best_coloring = deepcopy(coloring)
            if best_coloring not in coloring_candidates:
                # if high_crosstalk_pair not in best_coloring:
                coloring_candidates.append(best_coloring)

    return coloring_candidates



def partition_edges(
    backend: IBMQBackend,
    cross_talk_impacts: Dict[Tuple[int, int], Dict[Tuple[int, int], float]] = None,
    cross_talk_impact_threshold: float = 1.2,
    minimum_link_distance: int = 1,
) -> List[List[Tuple[int, int]]]:
    """
    Partition the edges of the graph represented by the given adjacency matrix.

    The edges of the graph will be colored and partitions will be formed by edges of
    the same color.
    Edges in the same partition can be executed in parallel safely.

    :param backend: targeted IBMQ backend.
    :param cross_talk_impacts: a dictionary that stores the impact of cross-talk
        on the CX gate error rates. The entry cross_talk_impact[u][v] stores the
        ratio between the CX error rate on link u when link v also executes a CX
        and the CX error rate on link u when executed alone. In other words,
        if there is cross-talk between links u and v, the entries [u][v] and [v][
        u] should be strictly larger than one. In practice it may happen that
        some entries are less than 1 because of benchmarking inaccuracies.
    :param cross_talk_impact_threshold: a threshold to determine whether a
        cross-talk error rate is significant or can be ignored.
    :param minimum_link_distance: the minimum distance (number of links) that
        should be ensured between two CX executed in parallel. This parameter can
        be used to avoid potential cross-talk when the real cross-talk
        information are not known.
        The default value is 1, i.e. links that are adjacent to each other cannot
        execute a CX in parallel.
        Values below 1 are not supported and will raise an error.
    :return: a list of partitions.
    :raise ValueError: If the minimum_link_distance value is not within the
            supported range (i.e. minimum_link_distance < 1).
    """
    if minimum_link_distance < 1:
        raise ValueError(
            f"The minimum_link_distance parameter cannot be below 1. "
            f"You gave {minimum_link_distance}."
        )
    if cross_talk_impacts is None:
        cross_talk_impacts = dict()

    adjacency_matrix = get_adjacency_matrix(backend)

    coloring = edge_coloring(
        adjacency_matrix,
        cross_talk_impacts,
        cross_talk_impact_threshold,
        minimum_link_distance,
    )
    # From the colored nodes of the dual graph, partition the edges of the graph.
    number_of_partitions: int = max(coloring.values())
    partitions: List[List[Tuple[int, int]]] = [
        list() for _ in range(number_of_partitions + 1)
    ]
    for edge, partition_id in coloring.items():
        partitions[partition_id].append(edge)

    return partitions



def partition_edges_candidates(
    backend: IBMQBackend,
    minimum_link_distance: int = 1,
) -> List[List[List[Tuple[int, int]]]]:
    """
    Partition the edges of the graph represented by the given adjacency matrix.

    The edges of the graph will be colored and partitions will be formed by edges of
    the same color.
    Cording candidate with high crosstalk pair with be discarded.
    Edges in the same partition can be executed in parallel safely.

    :param backend: targeted IBMQ backend.
    :param minimum_link_distance: the minimum distance (number of links) that
        should be ensured between two CX executed in parallel. This parameter can
        be used to avoid potential cross-talk when the real cross-talk
        information are not known.
        The default value is 1, i.e. links that are adjacent to each other cannot
        execute a CX in parallel.
        Values below 1 are not supported and will raise an error.
    :return: a list of partitions.
    :raise ValueError: If the minimum_link_distance value is not within the
            supported range (i.e. minimum_link_distance < 1).
    """
    if minimum_link_distance < 1:
        raise ValueError(
            f"The minimum_link_distance parameter cannot be below 1. "
            f"You gave {minimum_link_distance}."
        )

    adjacency_matrix = get_adjacency_matrix(backend)

    coloring_candidates = edge_coloring_candidates(
        adjacency_matrix,
        minimum_link_distance,
    )
    # From the colored nodes of the dual graph, partition the edges of the graph.
    partition_candidates = []
    for coloring in coloring_candidates:
        number_of_partitions: int = max(coloring.values())
        partitions: List[List[Tuple[int, int]]] = [
            list() for _ in range(number_of_partitions + 1)
        ]
        for edge, partition_id in coloring.items():
            partitions[partition_id].append(edge)
        # if [high_crosstalk_pair[0], high_crosstalk_pair[1]] in partitions or \
        #     [high_crosstalk_pair[1], high_crosstalk_pair[0]] in partitions:
        #     continue
        # else:
        #     partition_candidates.append(partitions)
        partition_candidates.append((partitions))

    return partition_candidates



def _get_cancellation_number(native_partitions: List[List[Tuple[int, int]]]) -> int:
    """Compute the number of 1-qubit gate cancellations allowed by the given partitions

    The number returned is the number of **cancellations**, meaning that it should be
    doubled if you are interested in the number of 1-qubit gates that are removed.

    :param native_partitions: partitions of **native** CX applications. If the given
        qubit pairs do not correspond to **native** (ctrl, trgt) CX application,
        the result will likely be false.
    :return: number of 1-qubit gate cancellations allowed by the given partition scheme
    """
    nqubits: int = max(max(max(t) for t in p) for p in native_partitions) + 1
    is_qubit_already_used = [False] * nqubits
    previous_is_target = [False] * nqubits
    cancellation_number: int = 0

    for partition in native_partitions:
        for pair in partition:
            ctrl, trgt = pair
            if not is_qubit_already_used[trgt]:
                cancellation_number += 1
            if previous_is_target[trgt]:
                cancellation_number += 1
            is_qubit_already_used[ctrl] = True
            is_qubit_already_used[trgt] = True
            previous_is_target[ctrl] = False
            previous_is_target[trgt] = True
    return cancellation_number


def sorted_partitions_by_cancellation(
    backend: IBMQBackend, partitions: List[List[Tuple[int, int]]]
) -> List[List[Tuple[int, int]]]:
    """Sort the given partitions to maximise 1-qubit gates cancellation.

    There are 2 opportunities to cancel gates:
    1. When the target qubit of the native CX gate needed to implement the CZ operation
       has never been involved in a preceding CZ.
    2. When 2 native CX gates have the same target and this target is not used by any
       other gates between the 2 CX.

    :param backend: the IBMQ backend considered.
    :param partitions: the partitions to sort. A sorted **copy** will be returned.
    :return: a **copy** of the given partitions sorted such that the number of gates
        that cancels each other is maximised.
    """
    native_coupling_map = get_native_coupling_map(backend)

    native_coupling_mapping = {u: u for u in native_coupling_map}
    native_coupling_mapping.update({u[::-1]: u for u in native_coupling_map})
    native_partitions: List[List[Tuple[int, int]]] = [
        [native_coupling_mapping[u] for u in partition] for partition in partitions
    ]

    m: int = len(native_partitions)
    best_cancellation_number: int = 0
    best_orderings: List[List[List[Tuple[int, int]]]] = list()

    # Find the best orderings in terms of cancellation
    for ordering in permutations(range(m), m):
        ordered_partitions = [native_partitions[i] for i in ordering]
        cancellation_number = _get_cancellation_number(ordered_partitions)
        if cancellation_number > best_cancellation_number:
            best_orderings = [deepcopy(ordered_partitions)]
            best_cancellation_number = cancellation_number
        elif cancellation_number == best_cancellation_number:
            best_orderings.append(deepcopy(ordered_partitions))

    # If there are several orderings that cancel the same number of 1-qubit gates,
    # we can also pick the best one.
    # Here we pick "best" as "the ordering that maximise the initial idle time of
    # the qubits.
    # For the moment, return the first ordering found.
    return best_orderings[0]



def find_qubit_start_operation(partitions: List[List[Tuple[int, int]]]) -> dict:
    """
    Find the start operation for each qubit of the circuit.
    :param partitions: the allocated partitions.
    :return: a dictionary that stores the first operation of each qubit.
    """
    qubit_start_operation = dict()

    for pair in partitions:
        for q1, q2 in pair:
            if qubit_start_operation.get(q1, 0) == 0:
                qubit_start_operation[q1] = (q1, q2)
            if qubit_start_operation.get(q2, 0) == 0:
                qubit_start_operation[q2] = (q1, q2)
    return qubit_start_operation



def find_operation_dependencies(operation: Tuple,
                                partitions: List[List[Tuple[int, int]]]) -> list:
    """
    Find the dependencies of the target operation. i.e., the operations that need to be finished before
    this operation.
    :param operation: input quantum operation.
    :param partitions: the allocated partitions.
    :return: the dependencies of the input operation.
    """
    operation_dependencies = []
    for partition in partitions:
        if operation in partition:
            break
        else:
            operation_dependencies.append(partition)
    return operation_dependencies



def find_qubit_start_time(backend: IBMQBackend, partitions: List[List[Tuple[int, int]]]) -> dict:
    """
    :param backend: the IBMQ backend considered.
    :param partitions: allocated partitions.
    :return: the start time of each qubit with the given partitions.
    """
    qubit_start_operation = find_qubit_start_operation(partitions)
    bprop = backend.properties()
    qubit_start_time = dict()
    for qubit, operation in qubit_start_operation.items():
        operation_dependencies = find_operation_dependencies(operation, partitions)
        start_time = 0
        for partition in operation_dependencies:
            max_pair_time = 0
            for pair in partition:
                if bprop.gate_length('cx', pair) > max_pair_time:
                    max_pair_time = bprop.gate_length('cx', pair)
            start_time += max_pair_time
        qubit_start_time[qubit] = start_time

    return qubit_start_time


def sort_paritions_by_reordering(backend: IBMQBackend, partitions_list: List[List[Tuple[int, int]]]
) -> List[List[Tuple[int, int]]]:
    """
    Sort the given partitions list to minimise the coherent error.

    coherent_error = sum(circuit_execution_time / min(t1(q),t2(q))

    :param backend: the IBMQ backend considered.
    :param partitions_list: the partitions to sort. A sorted **copy** will be returned.
    :return: the selected partition.
    """
    estimated_t = get_execution_time(backend)
    native_coupling_map = get_native_coupling_map(backend)
    bprop = backend.properties()
    native_coupling_mapping = {u: u for u in native_coupling_map}
    native_coupling_mapping.update({u[::-1]: u for u in native_coupling_map})

    best_ordering = []
    for partitions in partitions_list:
        native_partitions: List[List[Tuple[int, int]]] = [
            [native_coupling_mapping[u] for u in partition] for partition in partitions
        ]
        m: int = len(native_partitions)

        best_coherent_error = sys.maxsize
        for ordering in permutations(range(m), m):
            ordered_partitions = [native_partitions[i] for i in ordering]
            qubit_start_time = find_qubit_start_time(backend, ordered_partitions)
            coherent_error = 0

            for qubit, start_time in qubit_start_time.items():
                coherent_error += (estimated_t - start_time) / min(bprop.t1(qubit), bprop.t2(qubit))

            if coherent_error < best_coherent_error:
                best_coherent_error = coherent_error
                best_ordering.append(ordered_partitions)

    return best_ordering[-1]







