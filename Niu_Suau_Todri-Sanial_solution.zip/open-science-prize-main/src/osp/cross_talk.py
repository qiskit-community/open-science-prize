# ======================================================================================
#
# Copyright: CERFACS, LIRMM, Total S.A. - the quantum computing team (25/01/2021)
# Contributor: Adrien Suau (adrien.suau@cerfacs.fr)
#
# This program is free software: you can redistribute it and/or modify it under the
# terms of the GNU Lesser General Public License as published by the Free Software
# Foundation, either version 3 of the License, or (at your discretion) any later
# version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
# PARTICULAR PURPOSE.
#
# See the GNU Lesser General Public License for more details. You should have received
# a copy of the GNU Lesser General Public License along with this program. If not, see
# https://www.gnu.org/licenses/lgpl-3.0.txt
#
# ======================================================================================

from typing import Dict, Tuple


def to_cross_talk_impact(
    single_cx_error_rates: Dict[Tuple[int, int], float],
    double_cx_error_rates: Dict[Tuple[int, int], Dict[Tuple[int, int], float]],
) -> Dict[Tuple[int, int], Dict[Tuple[int, int], float]]:
    """Compute the cross-talk impacts from the error rates.

    :param single_cx_error_rates: a dictionary with pairs of qubits as key and the
        error rate of a single CX operation between the two qubits in the key when
        executed alone.
    :param double_cx_error_rates: a double-entry dictionary that takes as input two
        pairs of qubits u and v and returns the error rate observed on the CX
        executed between the qubits in u when another CX was executed between the
        qubits in v.
    :return: a dictionary that stores the impact of cross-talk on the CX gate error
        rates. The entry ret_value[u][v] stores the ratio between the CX error rate
        on link u when link v also executes a CX and the CX error rate on link u when
        executed alone. In other words, if there is cross-talk between links u and v,
        the entries [u][v] and [v][u] should be strictly larger than one. In practice it
        may happen that some entries are less than 1 because of benchmarking
        inaccuracies.
    """
    benchmarked_links = single_cx_error_rates.keys() & double_cx_error_rates.keys()
    cross_talk_impacts = {u: dict() for u in benchmarked_links}

    for u in benchmarked_links:
        single_error = single_cx_error_rates[u]
        for v, cross_talk_error in double_cx_error_rates[u].items():
            assert (
                v in benchmarked_links
            ), "Found a non-benchmarked link in the double_cx_error_rate dictionary."
            cross_talk_impacts[u][v] = cross_talk_error / single_error
    return cross_talk_impacts


benchmarks = [
    {
        "single_cx_errors": {
            (0, 1): 0.00846,
            (3, 5): 0.00742,
            (4, 5): 0.0109,
            (5, 6): 0.00736,
            (1, 2): 0.011,
            (1, 3): 0.00775,
        },
        "cross_talk_errors": {
            (0, 1): {(3, 5): 0.00742, (4, 5): 0.00757, (5, 6): 0.00738},
            (3, 5): {(0, 1): 0.00955, (1, 2): 0.0105},
            (4, 5): {(0, 1): 0.0112, (1, 2): 0.0118, (1, 3): 0.0261},
            (5, 6): {(0, 1): 0.00617, (1, 2): 0.00627, (1, 3): 0.0072},
            (1, 2): {(3, 5): 0.011, (4, 5): 0.00942, (5, 6): 0.0103},
            (1, 3): {(4, 5): 0.0264, (5, 6): 0.00931},
        },
    },
    {
        "single_cx_errors": {
            (0, 1): 0.00975,
            (3, 5): 0.0157,
            (4, 5): 0.00958,
            (5, 6): 0.00845,
            (1, 2): 0.00941,
            (1, 3): 0.00885,
        },
        "cross_talk_errors": {
            (0, 1): {(3, 5): 0.0093, (4, 5): 0.0102, (5, 6): 0.00865},
            (3, 5): {(0, 1): 0.0142, (1, 2): 0.0157},
            (4, 5): {(0, 1): 0.0118, (1, 2): 0.0118, (1, 3): 0.0253},
            (5, 6): {(0, 1): 0.00756, (1, 2): 0.00911, (1, 3): 0.0101},
            (1, 2): {(3, 5): 0.0106, (4, 5): 0.00952, (5, 6): 0.00933},
            (1, 3): {(4, 5): 0.0245, (5, 6): 0.0152},
        },
    },
]
