from typing import List, Tuple

import numpy

from qiskit.providers.ibmq import IBMQBackend
from qiskit.circuit.exceptions import CircuitError
from collections import defaultdict

def is_native_gate(backend: IBMQBackend, i: int, j: int) -> bool:
    """Check if (i, j) is the native CX gate

    :param backend: backend to consider.
    :param i: first qubit index involved in the CX.
    :param j: second qubit index involved in the CX.
    :return: the native CX operands as (control, target).
    """
    properties = backend.properties()
    ij_duration = properties.gate_property("cx", (i, j), "gate_length")[0]
    ji_duration = properties.gate_property("cx", (j, i), "gate_length")[0]
    return ij_duration < ji_duration


def get_native_gate(backend: IBMQBackend, i: int, j: int) -> Tuple[int, int]:
    """Returns the native CX operands as a (control, target) tuple.

    :param backend: backend to consider.
    :param i: first qubit index involved in the CX.
    :param j: second qubit index involved in the CX.
    :return: the native CX operands as (control, target).
    """
    if is_native_gate(backend, i, j):
        return i, j
    else:
        return j, i


def get_adjacency_matrix(backend: IBMQBackend) -> numpy.ndarray:
    """Compute the adjacency matrix of a given backend.

    :param backend: targeted IBMQ backend.
    :return: the adjacency matrix of the given backend.
    """
    # Recover the coupling map from the backend instance.
    configuration = backend.configuration()
    nqubits = configuration.n_qubits
    adjacency_matrix = numpy.zeros((nqubits, nqubits), dtype=int)
    for i, j in configuration.coupling_map:
        adjacency_matrix[i][j] = 1

    if not numpy.allclose(adjacency_matrix, adjacency_matrix.transpose()):
        raise CircuitError("The adjacency matrix must be symmetric.")
    return adjacency_matrix



def get_native_coupling_map(backend: IBMQBackend) -> List[Tuple[int, int]]:
    """Extract the native coupling map from the backend

    The native coupling map consists of the CX that can be performed natively,
    without the extra overhead of wrapping the CX between H gates.

    :param backend: backend considered.
    :return: the native coupling map of the given backend.
    """
    # Recover the coupling map from the backend instance.
    configuration = backend.configuration()
    native_coupling_map = set()
    for i, j in configuration.coupling_map:
        native_coupling_map.add(get_native_gate(backend, i, j))
    return list(native_coupling_map)

def get_max_qubit_degree_list(backend: IBMQBackend) -> List[int]:
    """
    Return the physical qubits of the backend that have the most connections.
    """
    configuration = backend.configuration()
    max_qubit_degree_list = []
    qubit_degree = dict()
    for source, sink in configuration.coupling_map:
        qubit_degree[source] = qubit_degree.get(source, 0) + 1
        qubit_degree[sink] = qubit_degree.get(sink, 0) + 1
    max_degree = max(qubit_degree.values())
    for key, value in qubit_degree.items():
        if value == max_degree:
            max_qubit_degree_list.append(key)
    return max_qubit_degree_list


def get_execution_time(backend: IBMQBackend) -> float:
    """
    Use the sum of CNOT execution time on the physical qubits with most connections to
    represent the total execution time. (ignore the single-qubit duration).
    :param backend: backend considered.
    :return: estimated execution time.
    """
    qubit_list = get_max_qubit_degree_list(backend)
    execution_time = 0
    bprop = backend.properties()
    bconfig = backend.configuration()
    for qubit in qubit_list:
        tmp_execution_time = 0
        for pair in bconfig.coupling_map:
            if qubit in pair:
                tmp_execution_time += bprop.gate_length('cx', pair)
        if tmp_execution_time > execution_time:
            execution_time = tmp_execution_time
    return execution_time / 2




