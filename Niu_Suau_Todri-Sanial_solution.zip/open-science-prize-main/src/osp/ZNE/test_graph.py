from osp.cross_talk import to_cross_talk_impact, benchmarks
from osp.plot import plot_cross_talk_impact
cross_talk_impacts = to_cross_talk_impact(benchmarks[0]["single_cx_errors"], benchmarks[0]["cross_talk_errors"])
plot_cross_talk_impact(cross_talk_impacts)