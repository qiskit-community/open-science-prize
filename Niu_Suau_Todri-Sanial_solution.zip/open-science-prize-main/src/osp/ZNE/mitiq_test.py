from qiskit import IBMQ
import mitiq
from qiskit import QuantumCircuit, execute, Aer
import qiskit
from qiskit.providers.aer import QasmSimulator
IBMQ.load_account()
provider = IBMQ.get_provider(hub='ibm-q-france',group='univ-montpellier',project='default')
backend = QasmSimulator.from_backend(provider.get_backend('ibmq_armonk'))
# qc = QuantumCircuit(2,2)
# qc.x(0)
# qc.cx(0,1)
# qc.measure(range(2),range(2))
# qc.draw(output='mpl')
#
#
# scale_factors = [1., 1.5, 2., 2.5, 3.]
# folded_circuits = [
#         mitiq.zne.scaling.fold_gates_at_random(qc, scale)
#         for scale in scale_factors
# ]
# print("circuit number is:", len(folded_circuits))
#
# shots = 8192
# backend_name = "qasm_simulator"
#
# job = qiskit.execute(
#    experiments=folded_circuits,
#    backend=Aer.get_backend(backend_name),
#    optimization_level=0,  # Important!
#    shots=shots
# )
#
# all_counts = [job.result().get_counts(i) for i in range(len(folded_circuits))]
# expectation_values = [counts.get("1 1") / shots for counts in all_counts]
#
# print("Unmitigated expectation value:", round(expectation_values[0], 3))
#
# fac = mitiq.zne.inference.RichardsonFactory(scale_factors)
# fac.instack, fac.outstack = scale_factors, expectation_values
# print(fac.instack)
# print(fac.outstack)
#
# zero_noise_value = fac.reduce()


qreg, creg = qiskit.QuantumRegister(1), qiskit.ClassicalRegister(1)
circuit = qiskit.QuantumCircuit(qreg, creg)
for _ in range(10):
    circuit.x(qreg)
circuit.measure(qreg, creg)

scale_factors = [1., 1.5, 2., 2.5, 3.]
folded_circuits = [
        mitiq.zne.scaling.fold_gates_at_random(circuit, scale)
        for scale in scale_factors
]

shots = 8192

job = qiskit.execute(
   experiments=folded_circuits,
   # Change backend=provider.get_backend(backend_name) to run on hardware
   #backend=provider.get_backend("ibmq_armonk"),
   backend = backend,
   optimization_level=0,  # Important!
   shots=shots
)

all_counts = [job.result().get_counts(i) for i in range(len(folded_circuits))]
expectation_values = [counts.get("0") / shots for counts in all_counts]

fac = mitiq.zne.inference.RichardsonFactory
zero_noise_value = fac.extrapolate(scale_factors, expectation_values)

print("error mitigation", zero_noise_value)

job = qiskit.execute(circuit, backend=backend, optimization_level=0, shots=shots)
counts = job.result().get_counts()
print("Without error mitigation", counts.get('0') / shots)