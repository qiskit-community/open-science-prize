# ======================================================================================
#
# Copyright: CERFACS, LIRMM, Total S.A. - the quantum computing team (25/01/2021)
# Contributor: Adrien Suau (adrien.suau@cerfacs.fr)
#
# This program is free software: you can redistribute it and/or modify it under the
# terms of the GNU Lesser General Public License as published by the Free Software
# Foundation, either version 3 of the License, or (at your discretion) any later
# version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
# PARTICULAR PURPOSE.
#
# See the GNU Lesser General Public License for more details. You should have received
# a copy of the GNU Lesser General Public License along with this program. If not, see
# https://www.gnu.org/licenses/lgpl-3.0.txt
#
# ======================================================================================

"""Graph State circuit."""

from typing import Dict, Tuple, List, Optional

from qiskit.providers.ibmq import IBMQBackend
from qiskit.circuit.quantumcircuit import QuantumCircuit
from qiskit import transpile
from osp.partition import partition_edges, sorted_partitions_by_cancellation, partition_edges_candidates, sort_paritions_by_reordering
from osp.hardware import get_native_gate
from qiskit.converters import dag_to_circuit, circuit_to_dag
from osp.CrosstalkAdaptive.crosstalk_adaptive_schedule import CrosstalkAdaptiveSchedule

def graph_state_circuit(
    backend: IBMQBackend,
    partitions: List[List[Tuple[int, int]]],
    circuit: Optional[QuantumCircuit] = None,
) -> QuantumCircuit:
    nqubits: int = (
        max(max(max(pair) for pair in partition) for partition in partitions) + 1
    )
    if circuit is None:
        circuit = QuantumCircuit(nqubits, name="graph_state")
    # Initial H will only be applied if not cancelled
    is_h_waiting: List[bool] = [True] * nqubits

    for parallel_edges in partitions:
        for parallel_edge in parallel_edges:
            ctrl, trgt = get_native_gate(backend, *parallel_edge)
            # First H gate. Apply a H only if no H gate is waiting. Else, simplify
            # the H gates and apply nothing.
            if is_h_waiting[trgt]:
                is_h_waiting[trgt] = False
            else:
                circuit.h(trgt)
            # CNOT: a H cannot wait on the target qubit (see above, first H),
            # but may wait on the control qubit. We cannot simplify it, so we apply it.
            if is_h_waiting[ctrl]:
                circuit.h(ctrl)
                is_h_waiting[ctrl] = False
            circuit.cx(ctrl, trgt)
            # Second H gate. Here we are sure no H gate is waiting on trgt or on ctrl
            # because we just applied a CX. As such, we do not apply the H gate and
            # save it for a possible cancellation.
            is_h_waiting[trgt] = True
        #circuit.barrier()
    # Finish by applying all the remaining, non-cancelled, H gates.
    for q in range(nqubits):
        if is_h_waiting[q]:
            circuit.h(q)

    return circuit



def graph_state_circuit_dense(
    backend: IBMQBackend,
    partitions: List[List[Tuple[int, int]]],
    #circuit: Optional[QuantumCircuit] = None,
) -> QuantumCircuit:
    nqubits: int = (
            max(max(max(pair) for pair in partition) for partition in partitions) + 1
    )
    circuit = QuantumCircuit(nqubits, name="graph_state")
    # Initial H will only be applied if not cancelled
    is_h_waiting: List[bool] = [True] * nqubits

    for parallel_edges in partitions:
        for parallel_edge in parallel_edges:
            ctrl, trgt = get_native_gate(backend, *parallel_edge)
            # First H gate. Apply a H only if no H gate is waiting. Else, simplify
            # the H gates and apply nothing.
            if is_h_waiting[trgt]:
                is_h_waiting[trgt] = False
            else:
                circuit.h(trgt)
            # CNOT: a H cannot wait on the target qubit (see above, first H),
            # but may wait on the control qubit. We cannot simplify it, so we apply it.
            if is_h_waiting[ctrl]:
                circuit.h(ctrl)
                is_h_waiting[ctrl] = False
            circuit.cx(ctrl, trgt)
            # Second H gate. Here we are sure no H gate is waiting on trgt or on ctrl
            # because we just applied a CX. As such, we do not apply the H gate and
            # save it for a possible cancellation.
            is_h_waiting[trgt] = True
        # circuit.barrier()
    # Finish by applying all the remaining, non-cancelled, H gates.
    for q in range(nqubits):
        if is_h_waiting[q]:
            circuit.h(q)

    bprop = backend.properties()
    crosstalk_prop = {}
    crosstalk_prop[(0, 1)] = {(3, 5): bprop.gate_error('cx', (0, 1)) * 0.92}
    crosstalk_prop[(3, 5)] = {(0, 1): bprop.gate_error('cx', (3, 5)) * 1.1,
                              (1, 2): bprop.gate_error('cx', (3, 5)) * 1.21}
    crosstalk_prop[(1, 2)] = {(3, 5): bprop.gate_error('cx', (1, 2)) * 1.06}
    crosstalk_prop[(1, 3)] = {(4, 5): bprop.gate_error('cx', (1, 3)) * 3.09,
                              (5, 6): bprop.gate_error('cx', (1, 3)) * 1.46}
    crosstalk_prop[(4, 5)] = {(1, 3): bprop.gate_error('cx', (4, 5)) * 2.52}
    crosstalk_prop[(5, 6)] = {(1, 3): bprop.gate_error('cx', (5, 6)) * 1.09}
    
    transpiled_circuit = transpile(circuit, initial_layout=list(range(nqubits)), backend=backend, optimization_level=2)
    dag_transpiled_circuit = circuit_to_dag(transpiled_circuit)
    pass_ = CrosstalkAdaptiveSchedule(bprop, crosstalk_prop=crosstalk_prop)
    schedule_dag = pass_.run(dag_transpiled_circuit)
    final_circuit = dag_to_circuit(schedule_dag)

    return final_circuit




class GraphState(QuantumCircuit):
    """Circuit to prepare a graph state."""

    def __init__(
        self,
        backend: IBMQBackend,
        cross_talk_impacts: Dict[Tuple[int, int], Dict[Tuple[int, int], float]] = None,
        cross_talk_impact_threshold: float = 1.2,
        minimum_link_distance: int = 1,
    ) -> None:
        """Create graph state preparation circuit.

        :param backend: targeted IBMQ backend.
        :param cross_talk_impacts: a dictionary that stores the impact of cross-talk
            on the CX gate error rates. The entry cross_talk_impact[u][v] stores the
            ratio between the CX error rate on link u when link v also executes a CX
            and the CX error rate on link u when executed alone. In other words,
            if there is cross-talk between links u and v, the entries [u][v] and [v][
            u] should be strictly larger than one. In practice it may happen that
            some entries are less than 1 because of benchmarking inaccuracies.
            Defaults to an empty dictionary, meaning that no cross-talk data is
            available and so cross-talk should not be considered.
        :param cross_talk_impact_threshold: a threshold to determine whether a
            cross-talk error rate is significant or can be ignored.
        :param minimum_link_distance: the minimum distance (number of links) that
            should be ensured between two CX executed in parallel. This parameter can
            be used to avoid potential cross-talk when the real cross-talk
            information are not known.
            The default value is 1, i.e. links that are adjacent to each other cannot
            execute a CX in parallel.
            Values below 1 are not supported and will raise an error.
        :raise CircuitError: If adjacency_matrix is not symmetric.
        :raise ValueError: If the minimum_link_distance value is not within the
            supported range (i.e. minimum_link_distance < 1).
        """
        if minimum_link_distance < 1:
            raise ValueError(
                f"The minimum_link_distance parameter cannot be below 1. "
                f"You gave {minimum_link_distance}."
            )

        if cross_talk_impacts is None:
            cross_talk_impacts = dict()

        configuration = backend.configuration()
        nqubits = configuration.n_qubits

        super().__init__(nqubits)
        self.__module__ = super().__module__

        partitions = partition_edges(
            backend,
            cross_talk_impacts,
            cross_talk_impact_threshold,
            minimum_link_distance,
        )

        print(f"{len(partitions)} partitions...")

        partitions = sorted_partitions_by_cancellation(backend, partitions)

        print("Done!")

        graph_state_circuit(backend, partitions, self)


class GraphStateDense(QuantumCircuit):
    """Circuit to prepare a graph state that has parallel executions with commutativity rules"""

    def __init__(
            self,
            backend: IBMQBackend,
    ) -> None:
        """Create graph state preparation circuit.

        :param backend: targeted IBMQ backend.
        :param cross_talk_impacts: a dictionary that stores the impact of cross-talk
            on the CX gate error rates. The entry cross_talk_impact[u][v] stores the
            ratio between the CX error rate on link u when link v also executes a CX
            and the CX error rate on link u when executed alone. In other words,
            if there is cross-talk between links u and v, the entries [u][v] and [v][
            u] should be strictly larger than one. In practice it may happen that
            some entries are less than 1 because of benchmarking inaccuracies.
            Defaults to an empty dictionary, meaning that no cross-talk data is
            available and so cross-talk should not be considered.
        :param cross_talk_impact_threshold: a threshold to determine whether a
            cross-talk error rate is significant or can be ignored.
        :raise CircuitError: If adjacency_matrix is not symmetric.
        """


        configuration = backend.configuration()
        nqubits = configuration.n_qubits

        super().__init__(nqubits)
        self.__module__ = super().__module__

        partitions = partition_edges_candidates(
            backend,
        )

        # Sort partitions by increasing length. This is a heuristic to try to
        # schedule the most CZ at the end of the circuit (a qubit is more stable in
        # the |0> state than in any other excited state).
        partition = sort_paritions_by_reordering(backend, partitions)
        self += graph_state_circuit_dense(backend, partition)



# from qiskit import IBMQ
#
#
# import numpy
#
# IBMQ.load_account()
#
# provider = IBMQ.get_provider(hub='ibm-q-france', group='univ-montpellier', project='default')
# shots = 8192
# backend = provider.get_backend('ibmq_casablanca')
#
# num_qubits = 7
#
# # adjacency matrix for `ibmq_casablanca`
#
# graph_state_circuits = GraphStateDense(backend)
# print(graph_state_circuits)
