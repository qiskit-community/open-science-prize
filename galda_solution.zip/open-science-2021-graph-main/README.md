# open-science-2021-graph
Solution to the Open Science Prize 2021: graph state challenge.

The solution consists of 4 improvements over the default quantum circuit for generating the graph state, `circuit_library.GraphState()`:
1.   Reducing the duration and the number of one-qubit (1q) gates in a single CZ gate by implementing a new decomposition into cross-resonance pulses and 1q gates.
2.   Optimization of the order of CZ gates in the 3-layer graph state circuit.
3.   Optimization of the "direction" of CZ gates (see the solution notebook) to further reduce the total circuit duration and 1q gate count.
4.   Dynamical decoupling on idling qubits.
